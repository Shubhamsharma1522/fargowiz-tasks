import React from "react";
import LoginForm from "./Components/LoginForm";

const App = () => {
  return (
    <div>
      <LoginForm />
    </div>
  );
};

export default App;
