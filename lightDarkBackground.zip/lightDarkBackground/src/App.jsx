import Ui from "./components/Ui.jsx";
import './App.css'

function App() {
  return <Ui />;
}

export default App;
