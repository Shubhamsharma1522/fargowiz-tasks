import React from "react";
import Calculate from "./components/Calculate";

const App = () => {
  return (
    <div>
      <Calculate />
    </div>
  );
};

export default App;
