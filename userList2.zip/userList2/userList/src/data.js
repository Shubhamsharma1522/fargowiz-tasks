

export const  DATA = 
      [
      {
        id: 1,
        title: "A",
        body: 'Body of User  ' ,
      },
      {
        id: 2,
        title: "B",
        body: "Body of User  ",
      },
      {
        id: 3,
        title: "C",
        body: "Body of User  ",
      },
      {
        id: 4,
        title: "D",
        body: "Body of User  ",
      },
      {
        id: 5,
        title: "E",
        body: "Body of User  ",
      },
      {
        id: 6,
        title: "F",
        body: "Body of User  ",
      },
      {
        id: 7,
        title: "G",
        body: "Body of User  ",
      },
      {
        id: 8,
        title: "H",
        body: "Body of User  ",
      },
      {
        id: 9,
        title: "I",
        body: "Body of User  ",
      },
      {
        id: 10,
        title: "J",
        body: "Body of User  ",
      },
      {
        id: 11,
        title: "K",
        body: "Body of User  ",
      },
      {
        id: 12,
        title: "L",
        body: "Body of User  ",
      },
      {
        id: 13,
        title: "M",
        body: "Body of User  ",
      },
    ];